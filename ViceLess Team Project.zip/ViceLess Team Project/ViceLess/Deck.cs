﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ViceLess
{
    public class Deck
    {
        private Random rng = new Random();
        //general playing Deck
        private List<Cards> playingDeck;
        private List<Cards> displayDeck; //cards that will be displayed on the screen
        private int sinBound = 5;
        List<List<Sin>> allSins = new List<List<Sin>>();
        List<Cards> customCardList = new List<Cards>();

        //properties for playing deck and display deck
        public List<Cards> PlayingDeck
        {
            get { return playingDeck; }
            set { playingDeck = value; }
        }

        public List<Cards> DisplayDeck
        {
            get { return displayDeck; }
        }

        public int SinBound
        {
            get { return sinBound; }
            set { sinBound = value; }
        }

        public List<Cards> CustomCardList
        {
            get { return customCardList; }
        }

        //constructor to create a new deck
        public Deck()
        {
            playingDeck = new List<Cards>();
            displayDeck = new List<Cards>();
            
        }

        //create a deck of variable size
        public void FillDeck(int deckSize, StreamReader reader, Texture2D spriteSheet)
        {
            try
            {
                reader = new StreamReader("..\\..\\..\\deck.txt");

                string[] statString;
                List<int> spriteSheetPos = new List<int>();
                List<int> cardStats = new List<int>();
                string[] sinName = new string[] { "Pride", "Greed", "Lust", "Envy", "Gluttony", "Wrath", "Sloth" }; //array of all the sin names so we can create new sin objects
                
                List<Sin> indvCardSins = new List<Sin>();

                string line;
                while ((line = reader.ReadLine()) != null) //reads through the file
                {
                    statString = line.Split(','); //splits each line into stats that we read
                    foreach (string stat in statString)
                    {
                        int stats = int.Parse(stat); //sets all the values to ints so we can use them
                        cardStats.Add(stats); //adds the stasts to the list so we can use them
                    }
                    for (int i = 0; i < cardStats.Count; i++) //goes through the list of cards stats
                    {
                        indvCardSins.Add(new Sin(sinName[i], cardStats[i])); //goes through and creates a new list for each individual card
                    }
                    Cards newCard = new Cards(spriteSheet, new Rectangle(0, 100, 80, 100), indvCardSins); //add the new card to playing deck
                    AddCard(newCard);
                    customCardList.Add(newCard); //add it to the list of custom cards
                    //clear out the lists so we can loop again
                    cardStats.Clear();
                    indvCardSins.Clear();
                }
                //close the reader
                reader.Close();

                //random generated cards once we structure them
                for (int i = playingDeck.Count; i < deckSize; i++)
                {
                    playingDeck.Add(new Cards(sinBound));
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine("Exception caught: {0},", e);
            }

            ShuffleDeck(); //shuffle the deck so the 10 custom cards are not on top
        }
        
        public List<List<Sin>> AllSins
        {
            get { return allSins; }
        }

        //adds a single card
        public void AddCard(Cards card)
        {
            playingDeck.Add(card);
        }
        
        public void ShuffleDeck() //method to shuffle deck
        {
            for(int i = 0; i < playingDeck.Count; i++) //loops for all of the current deck order
            {
                int randoCards;
                if (i < 10) { randoCards = i; }
                else { randoCards = rng.Next(0, playingDeck.Count); }
                playingDeck = MoveCards(randoCards, playingDeck);
            }
        }

        public List<Cards> MoveCards(int index, List<Cards> deck)
        {
            Cards moveCard = deck[index];
            deck.Remove(moveCard);
            deck.Add(moveCard);
            return deck;
        }

        //display a number of cards you can choose from
        public void DrawCards()
        {
            Vector2 center = new Vector2(475, 400);           
            List<Vector2> cardPos = new List<Vector2>();
            cardPos.Add(new Vector2(center.X + 250, center.Y)); //card directly to the right
            cardPos.Add(new Vector2(center.X + 250 * ((float)Math.Cos(Math.PI)), center.Y)); //card directly to the left
            cardPos.Add(new Vector2(center.X + 200 * ((float)Math.Cos(Math.PI / 4)), center.Y - 250 * ((float)Math.Sin(Math.PI / 4)))); //card rotated counter clockwise by 45 degrees
            cardPos.Add(new Vector2(center.X + 200 * ((float)Math.Cos((Math.PI * 3 )/ 4)), center.Y + 250 * ((float)Math.Sin((Math.PI * 3)/ 4)))); //card rotated counter clockwise by 135 degrees
            cardPos.Add(new Vector2(center.X, center.Y - 250 * ((float)Math.Sin((Math.PI * - 1 )/ 2)))); //card rotated counter clockwise by 270 degrees
            cardPos.Add(new Vector2(center.X + 200 * ((float)Math.Cos((Math.PI * - 1)/ 4)), center.Y - 250 * ((float)Math.Sin((Math.PI * - 1)/ 4)))); //card rotated clockwise by 45 degrees
            cardPos.Add(new Vector2(center.X + 200 * ((float)Math.Cos((Math.PI * -3) / 4)), center.Y + 250 * ((float)Math.Sin((Math.PI * -3) / 4)))); //card rotated clockwise by 135 degrees

            /*
            cardPos.Add(ShapeBatch.Line(center, length, (float)Math.PI / 4, Color.Blue)); x
            cardPos.Add(ShapeBatch.Line(center, length, ((float)Math.PI * 3) / 4, Color.Blue));x
            cardPos.Add(ShapeBatch.Line(center, length, ((float)Math.PI * -1) / 2, Color.Blue));
            cardPos.Add(ShapeBatch.Line(center, length, ((float)Math.PI * -1) / 4, Color.Blue));
            cardPos.Add(ShapeBatch.Line(center, length, ((float)Math.PI * -3) / 4, Color.Blue));
            cardPos.Add(ShapeBatch.Line(center, length, 0, Color.Blue));
            cardPos.Add(ShapeBatch.Line(center, length, (float)Math.PI, Color.Blue));
            */
            Rectangle newPosition;
            for(int i = 0; i < 7; i++)
            {
                newPosition = new Rectangle((int)cardPos[i].X, (int)cardPos[i].Y, 80, 100); //original position, in a line, is i * 80, 150
                displayDeck.Add(playingDeck[0]);
                playingDeck[0].CardOutline = newPosition;
                playingDeck.RemoveAt(0);
            }
            System.Diagnostics.Debug.WriteLine(playingDeck.Count);
        }
        public void ReturnCard(int index) //return a card to the deck
        {
            playingDeck.Add(displayDeck[index]);
            displayDeck.RemoveAt(index);
        }
        public void ReturnCards() //return all of the cards to the deck
        {
            foreach(Cards card in displayDeck)
            {
                playingDeck.Add(card);
            }
            displayDeck.Clear();
        }
    }
}
