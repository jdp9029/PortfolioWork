﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ViceLess
{
    class Button
    {
        //rectangle for the button
        Rectangle button;

        public Button(Rectangle button)
        {
            this.button = button;
        }

        //button pressed method
        public bool ButtonPressed(MouseState mState, MouseState prevMState)
        {
            return (mState.X >= button.X &&
                mState.X <= button.X + button.Width &&
                mState.Y >= button.Y &&
                mState.Y <= button.Y + button.Height) &&
                mState.LeftButton == ButtonState.Released &&
                prevMState.LeftButton == ButtonState.Pressed;
        }

        //draw button method
        public void DrawButton(SpriteBatch sb, SpriteFont font, Texture2D box, string text, Color buttonColor, Color textColor)
        {
            sb.Draw(box, button, buttonColor);
            sb.DrawString(font, text, new Vector2(button.X + (button.Width / 20), button.Y - 20 + (.5f * button.Height)), textColor);
        }
    }
}
