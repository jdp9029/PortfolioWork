﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace ViceLess
{
    enum GameState //create a game state enum
    {
        Menu, Options, HowToPlay, Gameplay, GameOver, Pause, Zoom //game states
    }
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private SpriteFont spriteFont;
        private SpriteFont titleFont;
        private SpriteFont cardFont;
        private SpriteFont vicelessfont;
        private SpriteFont cardStats;
        Random rng = new Random();
        
        //create the player and deck objects
        Player player1;
        Deck playingDeck;

        //a list of card(s) for if a player wants to see a card clearer
        Deck cardsZoom;
        

        //create the card texture and playing field
        Texture2D cardTexture;
        Texture2D playingField;
        Texture2D demoBoard;
        Texture2D nonOpaqueBox;
        Texture2D spriteSheet;

        //create a GameState and MouseState and a Previous Mouse State
        GameState gmState;
        KeyboardState kbState;
        KeyboardState prevKbState;
        MouseState mState;
        MouseState prevMState;

        //create a vector2 for the players stats and another for the cards stats
        Vector2 playerTextPosition;

        //stream reader and writer
        StreamWriter save;
        StreamReader read;

        // Keeps Track of data within the game
        string whoseTurn = "Wait your turn!";

        //Live Feed
        List<string> liveFeed = new List<string>();
        Vector2 feedPosition = new Vector2(750f, 710f);

        //Enemies
        List<Enemy> enemyList = new List<Enemy>();
        Enemy enemy1;
        Enemy enemy2;
        Enemy enemy3;
        Enemy enemy4;
        Enemy enemy5;
        Enemy enemy6;

        int timer = 0;
        int roundNumber;
        int turnNumber;

        //buttons
        Texture2D buttonTexture;
        Button MenuPlayButton = new Button(new Rectangle(350, 300, 300, 100));
        Button MenuOptionsButton = new Button(new Rectangle(350, 450, 300, 100));
        Button MenuInstructionsButton = new Button(new Rectangle(350, 600, 300, 100));
        Button GamePlayPauseButton = new Button(new Rectangle(800, 50, 200, 100));
        Button ReturnToMenu = new Button(new Rectangle(330, 100, 300, 100));
        Button OptionsIncreaseSinBoundButton = new Button(new Rectangle(600, 250, 350, 100));
        Button OptionsDecreaseSinBoundButton = new Button(new Rectangle(600, 400, 350, 100));
        Button loadSave = new Button(new Rectangle(350, 750, 300, 100));
        Button OptionsIncreaseWinConditionButton = new Button(new Rectangle(60, 250, 400, 100));
        Button OptionsDecreaseWinConditionButton = new Button(new Rectangle(60, 400, 400, 100));
        Button OptionsResetSettingsToDefaultButton = new Button(new Rectangle(350, 700, 325, 100));

        public Texture2D SpriteSheet
        {
            get { return spriteSheet; }
        }
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            
            //initialize the player and deck objects
            player1 = new Player();
            playingDeck = new Deck();
            //playingDeck.FillDeck(50, read, spriteSheet);
            //playingDeck.DrawCards();
            cardsZoom = new Deck();

            //setting the window size

            _graphics.PreferredBackBufferWidth = 1000;
            _graphics.PreferredBackBufferHeight = 1000;
            _graphics.ApplyChanges();

            //the game is not over so don't set the gamestate to gameover
            gmState = GameState.Menu;

            //get the mouse and previous mouse states

            //get the textPosition
            playerTextPosition = new Vector2(10, _graphics.PreferredBackBufferHeight / 2);
            //get round and turn Numbers
            roundNumber = 1;
            turnNumber = 1;

            // a list of possible enemy names we can choose from!
            enemyList.Add(new Enemy("Bundy")); enemyList.Add(new Enemy("Jack")); enemyList.Add(new Enemy("Kronos"));
            enemyList.Add(new Enemy("Cain")); enemyList.Add(new Enemy("Adam")); enemyList.Add(new Enemy("Diablo"));
            enemyList.Add(new Enemy("DIO")); enemyList.Add(new Enemy("Hades")); enemyList.Add(new Enemy("Chuck"));
            enemyList.Add(new Enemy("Luci")); enemyList.Add(new Enemy("Zeus")); enemyList.Add(new Enemy("Merlin"));
            enemyList.Add(new Enemy("Mumie")); enemyList.Add(new Enemy("Lucifer")); enemyList.Add(new Enemy("Baelz"));
            enemyList.Add(new Enemy("Eldlich")); enemyList.Add(new Enemy("MewTwo")); enemyList.Add(new Enemy("Aatrox"));
            enemyList.Add(new Enemy("Cthulu")); enemyList.Add(new Enemy("Tepes 3")); enemyList.Add(new Enemy("C#"));
            enemyList.Add(new Enemy("Mori")); enemyList.Add(new Enemy("Remila")); enemyList.Add(new Enemy("Corona"));

            //determine which enemy names we end up with 
            enemy1 = enemyList[rng.Next(enemyList.Count)];
            enemyList.Remove(enemy1);
            enemy2 = enemyList[rng.Next(enemyList.Count)];
            enemyList.Remove(enemy2);
            enemy3 = enemyList[rng.Next(enemyList.Count)];
            enemyList.Remove(enemy3);
            enemy4 = enemyList[rng.Next(enemyList.Count)];
            enemyList.Remove(enemy4);
            enemy5 = enemyList[rng.Next(enemyList.Count)];
            enemyList.Remove(enemy5);
            enemy6 = enemyList[rng.Next(enemyList.Count)];
            enemyList.Remove(enemy6);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            // TODO: use this.Content to load your game content here

            //load in the card and the card texture
            cardTexture = this.Content.Load<Texture2D>("Cardback");
            spriteFont = this.Content.Load<SpriteFont>("testText");
            demoBoard = this.Content.Load < Texture2D>("DemoBoard");
            playingField = this.Content.Load<Texture2D>("PlayingBoard");
            buttonTexture = this.Content.Load<Texture2D>("whitebox");
            titleFont = this.Content.Load<SpriteFont>("titleText");
            cardFont = this.Content.Load<SpriteFont>("CardFont");
            nonOpaqueBox = this.Content.Load<Texture2D>("whitebox2");
            vicelessfont = this.Content.Load<SpriteFont>("viceless");
            spriteSheet = this.Content.Load<Texture2D>("CardSpriteSheet");
            cardStats = this.Content.Load<SpriteFont>("cardStats");
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            //get the mouse state
            mState = Mouse.GetState();
            kbState = Keyboard.GetState();
            switch (gmState)
            {
                //if we are in the main menu
                case GameState.Menu:
                    //if the play button is pressed, move onto gameplay state
                    if(MenuPlayButton.ButtonPressed(mState, prevMState))
                    {
                        gmState = GameState.Gameplay;
                        timer = 0;
                        playingDeck.FillDeck(50, read, spriteSheet);
                        playingDeck.DrawCards();
                        player1.Games++;
                    }
                    //if the options button is pressed, move onto options state
                    if (MenuOptionsButton.ButtonPressed(mState, prevMState)) { gmState = GameState.Options; }
                    if (loadSave.ButtonPressed(mState, prevMState))
                    {
                        try
                        {
                            string file = "..\\..\\..\\save.txt";
                            read = new StreamReader(file);

                            //all of this to save the values of the sins down and set the player score to it xd
                            string[] statString; //array to store the split up information from the readline
                            List<int> playerStats = new List<int>(); //new list of ints to store all the sins after they've been parsed to int
                            string[] sinName = new string[] { "Pride", "Greed", "Lust", "Envy", "Gluttony", "Wrath", "Sloth" }; //array of all the sin names so we can create new sin objects
                            string line;
                            if ((line = read.ReadLine()) != null) //reads through the 1 line lol
                            {
                                statString = line.Split(',');
                                foreach (string stat in statString) //for every stat we need, parses them to int and adds them to playerStats
                                {
                                    int stats = int.Parse(stat);
                                    playerStats.Add(stats);
                                }
                                for (int i = 0; i < 7; i++) //goes through all of the sins, creating a new Sin object with each of them, then adding them to the player's sin Values
                                {
                                    Sin saveValue = new Sin(sinName[i], playerStats[i]); 
                                    player1.ArrayOfAllSins[i] = saveValue;
                                }

                                player1.Goal = playerStats[7]; //sets the player's end goal to whatever it was in the file
                                playingDeck.SinBound = playerStats[8]; //sets the rng pool to whatever it was in the file
                                roundNumber = playerStats[9];
                                turnNumber = playerStats[10];

                                // Universal stats
                                player1.Games = playerStats[11];
                                player1.Rounds = playerStats[12];
                            }

                            playingDeck.FillDeck(50, read, spriteSheet);
                            playingDeck.DrawCards();
                            for (int i = 1; i < (turnNumber); i++)
                            {
                                playingDeck.ReturnCard(0);
                            }
                            gmState = GameState.Gameplay; //jump straight into the gameplay!
                            read.Close(); //closes file reader
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine("Exception Caught: {0}", ex);
                        }
                    }

                    //if the instructions button is pressed, move onto instructions
                    if (MenuInstructionsButton.ButtonPressed(mState, prevMState)) { gmState = GameState.HowToPlay; }
                    break;


                //all buttons for options
                
                case GameState.Options:
                    
                    if (OptionsDecreaseSinBoundButton.ButtonPressed(mState, prevMState) && playingDeck.SinBound > 1) //if it is decreased
                    {
                        playingDeck.SinBound--;
                        playingDeck.PlayingDeck.Clear();
                        playingDeck.DisplayDeck.Clear();
                        //playingDeck.FillDeck(50, read, spriteSheet);
                        //playingDeck.DrawCards();
                    }

                    if (OptionsIncreaseSinBoundButton.ButtonPressed(mState, prevMState)) //if it is increased
                    {
                        playingDeck.SinBound++;
                        playingDeck.PlayingDeck.Clear();
                        playingDeck.DisplayDeck.Clear();
                        //playingDeck.FillDeck(50, read, spriteSheet);
                        //playingDeck.DrawCards();
                    }
                    //if the win condition is changed change it accordingly
                    if (OptionsIncreaseWinConditionButton.ButtonPressed(mState, prevMState)) { player1.Goal+=5; } //for increase
                    if(OptionsDecreaseWinConditionButton.ButtonPressed(mState, prevMState)) { player1.Goal-=5; } //for decrease

                    //this button resets the settings to their default values
                    if((playingDeck.SinBound!=5 || player1.Goal != 50) && OptionsResetSettingsToDefaultButton.ButtonPressed(mState, prevMState))
                    {
                        //reset their values
                        player1.Goal = 50;
                        playingDeck.SinBound = 5;

                        //implement the code that is required when sin bound is changed where the deck is remade
                        playingDeck.PlayingDeck.Clear();
                        playingDeck.DisplayDeck.Clear();
                        //playingDeck.FillDeck(50, read, spriteSheet);
                        //playingDeck.DrawCards();
                    }

                    //if the menu button is pressed go back to menu
                    if (ReturnToMenu.ButtonPressed(mState, prevMState)) { gmState = GameState.Menu; }
                    break;

                     //instructions menu
                case GameState.HowToPlay:
                        if(ReturnToMenu.ButtonPressed(mState, prevMState)) { gmState = GameState.Menu; } //button to return to menu
                        break;

                //if we are in gameplay
                case GameState.Gameplay:
                    {
                        //if its the player's turn
                        if ((roundNumber % 7) + turnNumber == 8 || (roundNumber % 7) + turnNumber == 1) 
                        {

                            whoseTurn = "Player1's Turn"; //say its the players turn
                            //cycle through the display deck
                            for (int i = 0; playingDeck.DisplayDeck.Count != 0 && i < playingDeck.DisplayDeck.Count;)
                            {
                                timer = 0; //reset the timer
                                if (playingDeck.DisplayDeck[i].CardSelected(mState, prevMState))//if a card gets selected
                                {
                                    player1.CardPicked(playingDeck.DisplayDeck[i]); //pick and return the card
                                    liveFeed.Add(player1.ToString(i)); //add to the live feed
                                    playingDeck.ReturnCard(i); //return a card to the regular deck
                                    whoseTurn = "Wait your turn!"; //change the text
                                    turnNumber++; //go to the next turn
                                    i = playingDeck.DisplayDeck.Count + 1; //break out of the for loop
                                }
                                
                                else if (playingDeck.DisplayDeck[i].CardZoom(mState, prevMState)) //if a card is selected to be zoomed in
                                {
                                    Cards zoom = playingDeck.DisplayDeck[i]; //adds card to a deck to be drawn
                                    cardsZoom.AddCard(zoom);
                                    gmState = GameState.Zoom;
                                    i = playingDeck.DisplayDeck.Count + 1;
                                }
                                
                                else //if the card isnt selected
                                {
                                    i++; //continue the loop to the next card
                                }
                            }
                        }

                        //if its not players turn
                        //enemy 1's turn
                        else if (timer == 100 && (((roundNumber % 7) + turnNumber == 9) || ((roundNumber % 7) + turnNumber == 2)))
                        {
                            Cards cardToRemove = enemy1.ChooseCard(playingDeck.DisplayDeck); //enemy chooses card
                            for (int i = 0; i < playingDeck.DisplayDeck.Count; i++)
                            {
                                if (cardToRemove == playingDeck.DisplayDeck[i])
                                {
                                    liveFeed.Add(enemy1.ToString(i)); //add the card to the live feed
                                }
                            }
                            playingDeck.DisplayDeck.Remove(cardToRemove); //remove the card from the display deck
                            turnNumber++; //go to the next turn
                            timer = 0; //reset timer
                        }


                        //enemy 2's turn
                        else if (timer == 100 && (((roundNumber % 7) + turnNumber == 10) || ((roundNumber % 7) + turnNumber == 3)))
                        {
                            Cards cardToRemove2 = enemy2.ChooseCard(playingDeck.DisplayDeck); //enemy chooses card
                            for (int i = 0; i < playingDeck.DisplayDeck.Count; i++)
                            {
                                if (cardToRemove2 == playingDeck.DisplayDeck[i])
                                {
                                    liveFeed.Add(enemy2.ToString(i)); //add the card to the live feed
                                }
                            }
                            playingDeck.DisplayDeck.Remove(cardToRemove2); //remove the card from the display deck
                            turnNumber++; //go to the next turn
                            timer = 0; //reset timer
                        }

                        //enemy 3's turn
                        else if (timer == 100 && (((roundNumber % 7) + turnNumber == 11) || ((roundNumber % 7) + turnNumber == 4)))
                        {
                            Cards cardToRemove3 = enemy3.ChooseCard(playingDeck.DisplayDeck); //enemy chooses card
                            for (int i = 0; i < playingDeck.DisplayDeck.Count; i++)
                            {
                                if (cardToRemove3 == playingDeck.DisplayDeck[i])
                                {
                                    liveFeed.Add(enemy3.ToString(i)); //add the card to the live feed
                                }
                            }
                            playingDeck.DisplayDeck.Remove(cardToRemove3); //remove the card from the display deck
                            turnNumber++; //go to the next turn
                            timer = 0; //reset timer
                        }
                        //enemy 4's turn
                        else if (timer == 100 && (((roundNumber % 7) + turnNumber == 12) || ((roundNumber % 7) + turnNumber == 5)))
                        {
                            Cards cardToRemove4 = enemy4.ChooseCard(playingDeck.DisplayDeck); //enemy chooses card
                            for (int i = 0; i < playingDeck.DisplayDeck.Count; i++)
                            {
                                if (cardToRemove4 == playingDeck.DisplayDeck[i])
                                {
                                    liveFeed.Add(enemy4.ToString(i)); //add the card to the live feed
                                }
                            }
                            playingDeck.DisplayDeck.Remove(cardToRemove4); //remove the card from the display deck
                            turnNumber++; //go to the next turn
                            timer = 0; //reset timer
                        }
                        //enemy 5's turn
                        else if (timer == 100 && (((roundNumber % 7) + turnNumber == 13) || ((roundNumber % 7) + turnNumber == 6)))
                        {
                            Cards cardToRemove5 = enemy5.ChooseCard(playingDeck.DisplayDeck); //enemy chooses card
                            for (int i = 0; i < playingDeck.DisplayDeck.Count; i++)
                            {
                                if (cardToRemove5 == playingDeck.DisplayDeck[i])
                                {
                                    liveFeed.Add(enemy5.ToString(i)); //add the card to the live feed
                                }
                            }
                            playingDeck.DisplayDeck.Remove(cardToRemove5); //remove the card from the display deck
                            turnNumber++; //go to the next turn
                            timer = 0; //reset timer
                        }
                        //enemy 6's turn
                        else if (timer == 100 && (((roundNumber % 7) + turnNumber == 7) || ((roundNumber%7) + turnNumber == 14)))
                        {
                            Cards cardToRemove6 = enemy6.ChooseCard(playingDeck.DisplayDeck); //enemy chooses card
                            for (int i = 0; i < playingDeck.DisplayDeck.Count; i++)
                            {
                                if (cardToRemove6 == playingDeck.DisplayDeck[i])
                                {
                                    liveFeed.Add(enemy6.ToString(i)); //add the card to the live feed
                                }
                            }
                            playingDeck.DisplayDeck.Remove(cardToRemove6); //remove the card from the display deck
                            turnNumber++; //go to the next turn
                            timer = 0; //reset timer
                        }
                        
                        //code after all turns have been made
                        //clear live feed
                        if (liveFeed.Count > 5)
                        {
                            liveFeed.RemoveAt(0);
                        }
                        
                        //if the display deck runs out of cards
                        if (playingDeck.DisplayDeck.Count == 0) 
                        {
                            playingDeck.ReturnCards(); //return all the cards in the deck
                            turnNumber = 1;
                            roundNumber++;
                            playingDeck.DrawCards(); //draw seven new ones
                            liveFeed.Add("--NEW HAND--"); //live feed is now 
                            timer = 0; //reset timer
                            player1.Rounds++;
                        }

                        //if the playing deck runs out of cards, it needs to be refilled
                        if(playingDeck.PlayingDeck.Count < 14)
                        {
                            playingDeck.PlayingDeck.Clear();
                            playingDeck.FillDeck(50, read, spriteSheet);
                        }

                        //increment timer - timer makes it so enemies wait and don't do their moves immediately before
                        //player can understand what is going on
                        timer++;

                        //game state changes for gameplay state
                        if (player1.IsGameOver()) //if the game is over
                        {
                            gmState = GameState.GameOver; //switch to game over GameState
                        }
                        if ((kbState.IsKeyDown(Keys.P) && prevKbState.IsKeyUp(Keys.P))
                            || GamePlayPauseButton.ButtonPressed(mState, prevMState)) //if pause is pressed
                        {
                            gmState = GameState.Pause; //switch to pause GameState
                        }
                    }
                    break;
                case GameState.Pause: //if we are paused
                    {
                        if ((kbState.IsKeyDown(Keys.P) && prevKbState.IsKeyUp(Keys.P))
                            || GamePlayPauseButton.ButtonPressed(mState, prevMState)) //if unpause is pressed
                        {
                            gmState = GameState.Gameplay; //go back to gameplay state
                        }
                        if (kbState.IsKeyUp(Keys.Enter) && prevKbState.IsKeyDown(Keys.Enter)) //file io saving player sins, and stats
                        {
                            save = new StreamWriter("../../../save.txt");
                            save.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}",
                                player1.ArrayOfAllSins[0].SValue,
                                player1.ArrayOfAllSins[1].SValue,
                                player1.ArrayOfAllSins[2].SValue,
                                player1.ArrayOfAllSins[3].SValue,
                                player1.ArrayOfAllSins[4].SValue,
                                player1.ArrayOfAllSins[5].SValue,
                                player1.ArrayOfAllSins[6].SValue,
                                player1.Goal,playingDeck.SinBound, 
                                roundNumber, 
                                turnNumber, 
                                player1.Games, 
                                player1.Rounds);
                            save.Close();
                        }
                        break;
                    }
                case GameState.GameOver: // If we reached the end of the game
                    {
                        // Saves the Game Data
                        save = new StreamWriter("../../../save.txt");
                        save.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}",
                            player1.ArrayOfAllSins[0].SValue,
                            player1.ArrayOfAllSins[1].SValue,
                            player1.ArrayOfAllSins[2].SValue,
                            player1.ArrayOfAllSins[3].SValue,
                            player1.ArrayOfAllSins[4].SValue,
                            player1.ArrayOfAllSins[5].SValue,
                            player1.ArrayOfAllSins[6].SValue,
                            player1.Goal, playingDeck.SinBound,
                            roundNumber,
                            turnNumber,
                            player1.Games,
                            player1.Rounds);
                        save.Close();

                        // If Menu Button is Pressed, go Back to Menu
                        if (ReturnToMenu.ButtonPressed(mState, prevMState))
                        {
                            gmState = GameState.Menu;

                            // Saves Universal Stats
                            int tempGames = player1.Games;
                            int tempRounds = player1.Rounds;

                            // Reset the players game stats
                            player1 = new Player();
                            player1.Games = tempGames;
                            player1.Rounds = tempRounds;
                            roundNumber = 1;
                            turnNumber = 1;
                            playingDeck = new Deck();
                        }
                        break;
                    }
                  
                   
                case GameState.Zoom:
                    if (mState.LeftButton == ButtonState.Pressed && prevMState.LeftButton == ButtonState.Released)
                    {
                        cardsZoom.PlayingDeck.Clear(); //clears the zoom deck
                        gmState = GameState.Gameplay; //returns to gameplay
                    }
                    break; 
                    
            }
            //if the player has all sin values under win condition, switch gamestate to game over!
            //at the current moment, there is no set up to restart the game
            
            prevMState = mState;
            prevKbState = kbState;

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Purple);
            _spriteBatch.Begin();

            // TODO: Add your drawing code here
            switch(gmState)
            {
                case GameState.Menu:
                    //draw the title
                    _spriteBatch.DrawString(vicelessfont, "V I C E L E S S", new Vector2(75, 75), Color.Yellow);

                    //draw the buttons in the menu
                    //play button, options, and instructions
                    MenuPlayButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Press Here to Play", Color.DarkRed, Color.Black);
                    MenuOptionsButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Press Here to Adjust Settings", Color.Red, Color.Black);
                    MenuInstructionsButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Press Here to Learn How to Play", Color.Orange, Color.Black);
                    loadSave.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Load your save file", Color.Yellow, Color.Black);
                    break;

                case GameState.Options:
                    //buttons for options
                    //increase and decrease sins
                    OptionsIncreaseSinBoundButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Increase Sin Magnitude\nCurrent Positive Bound: "
                        + playingDeck.SinBound + "\nCurrent Negative Bound: " + (playingDeck.SinBound + 3), Color.Orange, Color.Black);
                    OptionsDecreaseSinBoundButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Decrease Sin Magnitude\nCurrent Positive Bound: "
                        + playingDeck.SinBound + "\nCurrent Negative Bound: " + (playingDeck.SinBound + 3), Color.Orange, Color.Black);

                    //increase and decrease win conditions
                    OptionsIncreaseWinConditionButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Increase Win Threshold (Current value): "
                        + player1.Goal, Color.Red, Color.Black);
                    OptionsDecreaseWinConditionButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Decrease Win Threshold (Current value): "
                        + player1.Goal, Color.Red, Color.Black);
                    
                    //only if the settings are not default should the reset to default button appear
                    if(player1.Goal != 50 || playingDeck.SinBound != 5)
                    {
                        OptionsResetSettingsToDefaultButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Reset Settings to Default",
                        Color.Yellow, Color.Black);
                    }

                    

                    //return to menu
                    ReturnToMenu.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Press Here to return to menu", Color.DarkRed, Color.Black);
                    break;

                case GameState.HowToPlay:
                    //buttons for instruction menu
                    ReturnToMenu.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Press Here to return to menu", Color.DarkRed, Color.Black);


                    _spriteBatch.Draw(nonOpaqueBox, new Rectangle(50, 400, 900, 300), Color.Red);
                    //text for how to play
                    _spriteBatch.DrawString(cardFont, "Basics:\n" + "In the top left corner, you'll see the values of your current sins,\n" +
                        "and the value you need to reduce those sins to in order to win.\n" +
                        "In this game, there are a total of 7 players, you, along with 6 other NPC's.\n" +
                        "Each will take turns selecting a card from the 7 dealt to the pool.\n" +
                        "The card you can select will specific sin values, which will be listed. This can either be negative or positive.\n" +
                        "There is a small chance for a custom card.  Otherwise, card sin values are random.\n" + 
                        "When the deck runs out of cards, each card will be \"shuffled\" back in and a new deck will be formed. ", new Vector2(60, 450), Color.Black);
                    break;

                case GameState.Gameplay: //if we are in gameplay

                    //this line draws the table in the background (image likely to be replaced)
                    _spriteBatch.Draw(demoBoard, new Rectangle(0, 0, 1000, 1000), Color.White);
                    //draw the pause button
                    GamePlayPauseButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Pause", Color.Orange, Color.Black);

                    //draw the live feed text
                    _spriteBatch.DrawString(cardFont, "Live Feed:", feedPosition, Color.Black);
                    for(int i = 0; i < liveFeed.Count; i++)
                    {
                        _spriteBatch.DrawString(cardFont, "\n" + liveFeed[i], new Vector2(745, 710 + (20*i)), Color.Black);
                    }
                    //draw the directive that will tell the player when it is his/her turn
                    _spriteBatch.DrawString(cardFont, whoseTurn, new Vector2(750, 685), Color.Black);

                    int x;
                    //cycle through the display deck
                    foreach (Cards card in playingDeck.DisplayDeck) 
                    {
                        //drawing each card in the deck
                        x = IndexOf(playingDeck.CustomCardList, card);
                        if (x != int.MaxValue)
                        {
                            DrawCard(_spriteBatch, new Rectangle(card.CardOutline.X, card.CardOutline.Y,
                                card.CardOutline.Width, card.CardOutline.Height), x);
                        }
                        else
                        {
                            _spriteBatch.Draw(cardTexture, card.CardOutline, Color.White);
                            //drawing string modifiers and card information
                            for (int i = 0; i < card.ArrayOfAllSins.Length; i++)
                            {
                                _spriteBatch.DrawString(cardFont,
                                    String.Format("{0}: {1}", card.ArrayOfAllSins[i].Name, card.ArrayOfAllSins[i].SValue),
                                    new Vector2(card.CardOutline.X, card.CardOutline.Y + card.CardOutline.Height + (i * 17)),
                                    Color.Black);
                            }
                        }
                                              
                    }

                    _spriteBatch.Draw(cardTexture, new Rectangle(475, 400, 80, 100), Color.White); //prints the deck at the center

                    //drawing player stats
                    for (int i = 0; i < player1.ArrayOfAllSins.Length; i++)
                    {
                        _spriteBatch.DrawString(spriteFont, 
                            String.Format("{0}: {1}/{2}", player1.ArrayOfAllSins[i].Name, player1.ArrayOfAllSins[i].SValue, player1.Goal),
                            new Vector2(10, 10 + (i * 15)), 
                            Color.Black);
                    }
                    break;

                    //if we are paused
                case GameState.Pause:
                    GraphicsDevice.Clear(Color.DarkRed);

                    //draw the unpause button
                    GamePlayPauseButton.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Unpause", Color.Orange, Color.Black);

                    // Press Enter to Save
                    _spriteBatch.DrawString(cardFont, "Press Enter To Save Your Progress!", new Vector2(200, 100), Color.Black);
                    break;

                    //if we are in game over
                case GameState.GameOver:
                    {
                        // Dialog for Winning
                        _spriteBatch.DrawString(cardFont, String.Format("After seeing your sin counters drop to below {0} the" +
                            " devil decided to\n\n re-evaluate your sentencing, and thus you were sent to heaven", player1.Goal) , new Vector2(250, 350), Color.Black);

                        // Statistics
                        _spriteBatch.DrawString(cardFont, String.Format("Total Games: {0}", player1.Games), new Vector2(300, 500), Color.Black);
                        _spriteBatch.DrawString(cardFont, String.Format("Total Rounds: {0}", player1.Rounds), new Vector2(300, 600), Color.Black);
                        _spriteBatch.DrawString(cardFont, String.Format("Avg Rounds/Game: {0}", player1.Rounds / player1.Games), new Vector2(300, 700), Color.Black);

                        // draw the return to menu button
                        ReturnToMenu.DrawButton(_spriteBatch, cardFont, nonOpaqueBox, "Press Here to return to menu", Color.Orange, Color.Black);
                        break;
                    }

                    //zoom gamestate
                case GameState.Zoom:
                    _spriteBatch.Draw(playingField, new Rectangle(0, 0, 1000, 1000), Color.White); //draw the background still

                    int z;
                    foreach (Cards card in cardsZoom.PlayingDeck) //for the single card in zoom deck
                    {
                        z = IndexOf(playingDeck.CustomCardList, card);
                        if (z != int.MaxValue) //if the card is a custom card
                        {
                            DrawCard(_spriteBatch, new Rectangle(237, 100, //draw the custom card
                                card.CardOutline.Width * 7, card.CardOutline.Height * 8), z);
                        }
                        else //draw an rng card
                        {
                            _spriteBatch.Draw(cardTexture, new Rectangle(237, 0, 600, 800), Color.White);
                            for (int i = 0; i < card.ArrayOfAllSins.Length; i++)
                            {
                                _spriteBatch.DrawString(cardStats,
                                        String.Format("{0}: {1}", card.ArrayOfAllSins[i].Name, card.ArrayOfAllSins[i].SValue),
                                        new Vector2(475, 400 + i * 33),
                                        Color.Black);
                            }
                        }
                    }

                    //drawing player stats
                    for (int i = 0; i < player1.ArrayOfAllSins.Length; i++)
                    {
                        _spriteBatch.DrawString(spriteFont,
                            String.Format("{0}: {1}/{2}", player1.ArrayOfAllSins[i].Name, player1.ArrayOfAllSins[i].SValue, player1.Goal),
                            new Vector2(10, 10 + (i * 15)),
                            Color.Black);
                    }
                    break;
            }
            _spriteBatch.End();
            base.Draw(gameTime);
        }

        //drawcard method for the custom cards
        public void DrawCard(SpriteBatch spriteBatch, Rectangle recty, int spriteSheetPos)
        {
            spriteBatch.Draw(spriteSheet, recty, new Rectangle(600 * spriteSheetPos , 0, 600, 800), Color.White);
        }

        //an index of method that returns max value if the card is not in the list
        public int IndexOf(List<Cards> list, Cards card)
        {
            if (list.Contains(card))
            {
                return list.IndexOf(card) % 10;
            }
            return int.MaxValue;
        }
    }
}
