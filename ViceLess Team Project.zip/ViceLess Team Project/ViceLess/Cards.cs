﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ViceLess
{
    public class Cards
    {
        //declaring fields used
        private Random rng = new Random(); //random value
        //an array for every sin with the sin name followed by the sin value - on a card, the sin value starts at zero until you use GetSinValues()
        private Sin[] arrayOfAllSins;
        private Rectangle cardOutline;
        private int summationValue = 0; //the sum of all sin values
        

        //loading in spriteSheet of cards
        Texture2D spriteSheet;

        const int cardOffSetY = 0; //honestly i have no idea what this is for but it's in the mario walking PE
        const int cardHeight = 600; //the card's height in the spritesheet
        const int cardWidth = 800; //the card's width in the spritesheet

        //properties
        public Sin[] ArrayOfAllSins
        {
            get { return arrayOfAllSins; }
            set { arrayOfAllSins = value; }
        }
        public Rectangle CardOutline
        {
            get { return cardOutline; }
            set { cardOutline = value; }
        }

        public int SummationValue
        {
            get { return summationValue; }
        }
        
        //constructor for CUSTOMLY CREATED CARDS
        public Cards(Texture2D spriteSheet, Rectangle cardOutline, List<Sin> sinValues)
        {
            arrayOfAllSins = new Sin[7];
            this.spriteSheet = spriteSheet;
            this.cardOutline = cardOutline;
            for (int i = 0; i < sinValues.Count; i++)
            {
                arrayOfAllSins[i] = sinValues[i];
                arrayOfAllSins[i].SValue = sinValues[i].SValue;
                arrayOfAllSins[i].Name = sinValues[i].Name;
            }

            //add the values to the summation values
            for (int i = 0; i < arrayOfAllSins.Length; i++)
            {
                summationValue += arrayOfAllSins[i].SValue;
            }
        }
        

        //constructor for RNG cards, including setting up a random sin value per card
        public Cards(int sinBound)
        {
            arrayOfAllSins = new Sin[] { new Sin("Pride", rng.Next(/*-3*/ - sinBound,sinBound + 1)), new Sin("Greed", rng.Next(/*-3*/ - sinBound,sinBound + 1)),
                new Sin("Lust", rng.Next(-3 - sinBound,sinBound + 1)), new Sin("Envy", rng.Next(-3 - sinBound,sinBound + 1)),
                new Sin("Gluttony", rng.Next(-3 - sinBound,sinBound + 1)), new Sin("Wrath", rng.Next(-3 - sinBound,sinBound + 1)),
                new Sin("Sloth", rng.Next(-3 - sinBound,sinBound + 1))};
            
            cardOutline = new Rectangle(0, 100, 80, 100);

            //add the values to the summation values
            for(int i = 0; i < arrayOfAllSins.Length; i++)
            {
                summationValue += arrayOfAllSins[i].SValue;
            }
        }

        public bool CardSelected(MouseState mState, MouseState prevMState)
        {
            return mState.X >= cardOutline.X &&
                mState.X <= cardOutline.X + cardOutline.Width &&
                mState.Y >= cardOutline.Y &&
                mState.Y <= cardOutline.Y + cardOutline.Height &&
                mState.LeftButton == ButtonState.Released &&
                prevMState.LeftButton == ButtonState.Pressed;
        }

        public bool CardZoom(MouseState mState, MouseState prevMState)
        {
            return mState.X >= cardOutline.X &&
                mState.X <= cardOutline.X + cardOutline.Width &&
                mState.Y >= cardOutline.Y &&
                mState.Y <= cardOutline.Y + cardOutline.Height &&
                mState.RightButton == ButtonState.Released &&
                prevMState.RightButton == ButtonState.Pressed;
        }

    }
}
