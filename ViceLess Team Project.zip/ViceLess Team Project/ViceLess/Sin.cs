﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ViceLess
{
    public class Sin
    {
        //declaring fields - Ryan Shu
        private string name; //name of the sin
        private int sValue; // name of the value

        //properties of the sin
        //once a name is set it won't be changed, so no need for a set {}
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        //value is always changing, so it can be set
        public int SValue
        {
            get { return sValue; }
            set { sValue = value; } //should we make a method for modifying the sin value, like a public void Increase/DecreaseValue, or should we just let it be a set block?
        }
        //sin constructor
        public Sin(string name, int sValue)
        {
            this.name = name;
            this.sValue = sValue;
        }
    }
}
