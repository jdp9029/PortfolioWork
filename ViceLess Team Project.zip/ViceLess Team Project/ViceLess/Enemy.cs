﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViceLess
{
    class Enemy
    {
        //an array for all of the sin values
        Sin[] arrayOfAllSins = new Sin[7];
        //a string for the Enemy name
        string name;
        Random rng = new Random();

        //constructor that initializes the two fields
        public Enemy(string name)
        {
            arrayOfAllSins = new Sin[] { new Sin("pride", 100), new Sin("greed", 100), new Sin("lust", 100), new Sin("envy", 100),
                new Sin("gluttony", 100), new Sin("wrath", 100), new Sin("sloth", 100)};
            this.name = name;
        }

        //property for name
        public string Name
        {
            get { return name; }
        }

        //choose a card in the display deck
        //for now, the enemy just selects the card with the largest summation of values
        
        public Cards ChooseCard(List<Cards> displayDeck)
        {
            //original logic for choose card
            /*Cards returnCard = new Cards(5); //this will be the card that gets returned
            int summationValue = -100; //used to compare the sin values of the cards
            foreach(Cards card in displayDeck) //for each card in the deck
            {
                if (card.SummationValue > summationValue) //if the card has the greater summation value than the current value
                {
                    //set a new balance for the standard value
                    summationValue = card.SummationValue;
                    returnCard = card; //set a new card to return
                }
            }
            
            return returnCard; //return whichever card has the highest summation value*/

            return displayDeck[rng.Next(displayDeck.Count)];
        }

        //returns a message for the live feed, or summarizes what card the enemy chose
        public string ToString(int cardIndex)
        {
            return String.Format("{0} chose card number {1}", name, cardIndex);
        }
        
    }
}
