﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace ViceLess
{
    public class Player
    {
        //an array for every sin with the sin name followed by the sin value - on a player, the sin value starts at 100 until you use SelectCard()
        private Sin[] arrayOfAllSins;
        private int goal;
        private int num_games;
        private int num_rounds;

        public Sin[] ArrayOfAllSins
        {
            get { return arrayOfAllSins; }
            set { arrayOfAllSins = value; }
        }

        public int Goal
        {
            get { return goal; }
            set { goal = value; }
        }

        public int Games
        {
            get { return num_games; }
            set { num_games = value; }
        }

        public int Rounds
        {
            get { return num_rounds; }
            set { num_rounds = value; }
        }

        //constructor
        public Player()
        {
            arrayOfAllSins = new Sin[] { new Sin("pride", 100), new Sin("greed", 100), new Sin("lust", 100), new Sin("envy", 100),
                new Sin("gluttony", 100), new Sin("wrath", 100), new Sin("sloth", 100)};

            // To Be Implemented: Grab Goal Value from File
            goal = 50;
            num_games = 0;
            num_rounds = 0;
        }

        //change the statistics for the player given a selected card
        public void CardPicked(Cards cardPicked)
        { //go through the list of player sins and card sins
            for (int i = 0; i < arrayOfAllSins.Length; i++)
            {
                arrayOfAllSins[i].SValue += cardPicked.ArrayOfAllSins[i].SValue;
            }
        }

        //is the game over (run this in game1.Update to change gamestates)
        public bool IsGameOver()
        {
            //if any sin value is greater than 50, keep the game running
            foreach(Sin sin in arrayOfAllSins)
            {
                if(sin.SValue > goal)
                {
                    return false;
                }
            }
            //if not, its all over
            return true;
        }

        //returns a message for the live feed, or summarizes what card the player chose
        public string ToString(int cardIndex)
        {
            return String.Format("Player 1 chose card number {0}", cardIndex);
        }
    }
}
