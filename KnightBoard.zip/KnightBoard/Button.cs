﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace KnightBoard
{
    class Button
    {
        public Button(Texture2D bckgrd, Rectangle recty)
        {
            this.Background = bckgrd;
            this.Recty = recty;
            this.Color = Color.White;
        }

        public Texture2D Background
        {
            get;set;
        }

        public Rectangle Recty
        {
            get;set;
        }

        public int Distance
        {
            get;set;
        }

        public Color Color
        {
            get;set;
        }

        public Button prevButton
        {
            get;set;
        }
    }
}
