﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace KnightBoard
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Texture2D eachTile;
        private SpriteFont text;
        private SpriteFont instructions;
        private Button[,] board;
        private MouseState mState;
        private MouseState prevMState;

        private Button knightPlacement;
        private List<Button> oneJump = new List<Button>();
        private List<Button> twoJumps = new List<Button>();
        private List<Button> threeJumps = new List<Button>();
        private List<Button> fourJumps = new List<Button>();
        private List<Button> fiveJumps = new List<Button>();
        private List<Button> sixJumps = new List<Button>();

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            _graphics.PreferredBackBufferWidth = 1400;
            _graphics.PreferredBackBufferHeight = 1000;
            _graphics.ApplyChanges();

            board = new Button[8, 8];

            //draw board
            for (int x = 0; x < 8; x++)
            {
                for (int y = 0; y < 8; y++)
                {
                    board[x, y] = new Button(eachTile, new Rectangle(50 + (x * 100), 100 + (y * 100), 100, 100));
                }
            }
            knightPlacement = board[1, 7];
            BoardManager();

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            eachTile = this.Content.Load<Texture2D>("whitey");
            text = this.Content.Load<SpriteFont>("text");
            instructions = this.Content.Load<SpriteFont>("instructions");
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            mState = Mouse.GetState();

            // TODO: Add your update logic here
            if(ButtonSelected() != null)
            {
                knightPlacement = ButtonSelected();
                knightPlacement.Color = Color.Black;

                foreach(Button button in board)
                {
                    if(button != knightPlacement && button.Color != Color.Gray) { button.Color = Color.White; }
                }
            }

            if(GreyedOut() != null && GreyedOut() != knightPlacement)
            {
                foreach (Button button in board)
                {
                    if (button != knightPlacement && button != GreyedOut() && button.Color != Color.Gray)
                    {
                        button.Color = Color.White;
                    }
                }
                if (GreyedOut().Color == Color.Gray) { GreyedOut().Color = Color.White; }
                else { GreyedOut().Color = Color.Gray; }
            }

            BoardManager();

            if(Hover() != null && Hover() != knightPlacement && Hover().Distance != int.MaxValue && Hover().Color != Color.Gray)
            {
                Button path = Hover();
                path.Color = Color.LightBlue;
                while (path != knightPlacement && path.prevButton != null)
                {
                    path.Color = Color.LightBlue;
                    path = path.prevButton;
                }
            }

            prevMState = Mouse.GetState();
            
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            _spriteBatch.Begin();

            // TODO: Add your drawing code here
            
            //draw board
            foreach(Button button in board)
            {
                _spriteBatch.Draw(eachTile, button.Recty, button.Color);
                _spriteBatch.DrawString(text, TextReturn(button), new Vector2(button.Recty.X + 40, button.Recty.Y + 40), Color.Black);
            }

            _spriteBatch.DrawString(text, "Knight Checker", new Vector2(380, 50), Color.Black);

            _spriteBatch.DrawString(text, "How to Use Knight Checker", new Vector2(980, 110), Color.Black);
            _spriteBatch.DrawString(instructions,
                "The point of the Knight Checker is to determine\n" +
                "how many moves it would take a knight in Chess\nto reach any given tile at once.\n\n" +
                "To move the knight to a tile, left click the tile.\n" +
                "To remove a tile from consideration (symbolizing a tile\n" +
                "that the player does not want to or cannot move into),\n" +
                "right click the tile. To add a tile back into consideration,\n" +
                "right click the tile again.\n\n" + 

                "To discover the path from the knight to a given tile,\n" +
                "hover over the tile and the path will display in blue.\n" +
                "The system will not determine paths greater than six\n" +
                "jumps or paths to tiles that the knight cannot reach."
                ,new Vector2(880, 160), Color.Black);

            _spriteBatch.End();
            base.Draw(gameTime);
        }

        private string TextReturn(Button b)
        {
            if(oneJump.Contains(b)) { return 1.ToString(); }
            if (twoJumps.Contains(b)) { return 2.ToString(); }
            if (threeJumps.Contains(b)) { return 3.ToString(); }
            if (fourJumps.Contains(b)) { return 4.ToString(); }
            if (fiveJumps.Contains(b)) { return 5.ToString(); }
            if (sixJumps.Contains(b)) { return 6.ToString(); }
            if(b.Color == Color.Gray) { return ""; }
            return ">6";
        }

        private void BoardManager()
        {
            oneJump.Clear(); twoJumps.Clear(); threeJumps.Clear(); fourJumps.Clear(); fiveJumps.Clear(); sixJumps.Clear();
            foreach(Button butt in board) { if (butt.Color != Color.Gray) { butt.Color = Color.White; } }
            knightPlacement.Color = Color.Black;

            for (int x = 0; x < 8; x++)
            {
                for (int y = 0; y < 8; y++)
                {
                    if (board[x, y].Color == Color.White && Connected(x, y, GetXIndex(knightPlacement), GetYIndex(knightPlacement)))
                    {
                        board[x, y].Color = Color.Green;
                        board[x, y].prevButton = knightPlacement;
                        oneJump.Add(board[x, y]);
                    }
                }
            }

            foreach (Button startCopy in oneJump)
            {
                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        if (board[x, y].Color == Color.White && Connected(x, y, GetXIndex(startCopy), GetYIndex(startCopy)))
                        {
                            board[x, y].Color = Color.LightGreen;
                            board[x, y].prevButton = startCopy;
                            twoJumps.Add(board[x, y]);
                        }
                    }
                }
            }

            foreach (Button startCopy in twoJumps)
            {
                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        if (board[x, y].Color == Color.White && Connected(x, y, GetXIndex(startCopy), GetYIndex(startCopy)))
                        {
                            board[x, y].Color = Color.Yellow;
                            board[x, y].prevButton = startCopy;
                            threeJumps.Add(board[x, y]);
                        }
                    }
                }
            }

            foreach (Button startCopy in threeJumps)
            {
                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        if (board[x, y].Color == Color.White && Connected(x, y, GetXIndex(startCopy), GetYIndex(startCopy)))
                        {
                            board[x, y].Color = Color.Red;
                            board[x, y].prevButton = startCopy;
                            fourJumps.Add(board[x, y]);
                        }
                    }
                }
            }

            foreach (Button startCopy in fourJumps)
            {
                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        if (board[x, y].Color == Color.White && Connected(x, y, GetXIndex(startCopy), GetYIndex(startCopy)))
                        {
                            board[x, y].Color = Color.Brown;
                            board[x, y].prevButton = startCopy;
                            fiveJumps.Add(board[x, y]);
                        }
                    }
                }
            }

            foreach (Button startCopy in fiveJumps)
            {
                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        if (board[x, y].Color == Color.White && Connected(x, y, GetXIndex(startCopy), GetYIndex(startCopy)))
                        {
                            board[x, y].Color = Color.DarkRed;
                            board[x, y].prevButton = startCopy;
                            sixJumps.Add(board[x, y]);
                        }
                    }
                }
            }

            foreach(Button butt in board)
            {
                if (oneJump.Contains(butt)) { butt.Distance = 1; }
                else if (twoJumps.Contains(butt)) { butt.Distance = 2; }
                else if (threeJumps.Contains(butt)) { butt.Distance = 3; }
                else if (fourJumps.Contains(butt)) { butt.Distance = 4; }
                else if (fiveJumps.Contains(butt)) { butt.Distance = 5; }
                else if (sixJumps.Contains(butt)) { butt.Distance = 6; }
                else if (butt.Color == Color.White || butt.Color == Color.Gray || butt.Color == Color.Black || butt.Color == Color.LightBlue)
                { butt.Distance = int.MaxValue; }
            }
        }

        private bool Connected(int x, int y, int starterX, int starterY)
        {
            if (((starterX + 2 == x) && (starterY + 1 == y) && (starterX + 2 < 8) && (starterY + 1 < 8)) ||
                ((starterX + 1 == x) && (starterY + 2 == y) && (starterX + 1 < 8) && (starterY + 2 < 8)) ||
                ((starterX - 1 == x) && (starterY + 2 == y) && (starterX - 1 >= 0) && (starterY + 2 < 8)) ||
                ((starterX - 2 == x) && (starterY + 1 == y) && (starterX - 2 >= 0) && (starterY + 1 < 8)) ||
                ((starterX - 2 == x) && (starterY - 1 == y) && (starterX - 2 >= 0) && (starterY - 1 >= 0)) ||
                ((starterX - 1 == x) && (starterY - 2 == y) && (starterX - 1 >= 0) && (starterY - 2 >= 0)) ||
                ((starterX + 2 == x) && (starterY - 1 == y) && (starterX + 2 < 8) && (starterY - 1 >= 0)) ||
                ((starterX + 1 == x) && (starterY - 2 == y) && (starterX + 1 < 8) && (starterY - 2 >= 0))
                )
            {
                return true;
            }
            else { return false; }
        }

        private int GetXIndex(Button b)
        {
            for(int x = 0; x < 8; x++)
            {
                for(int y = 0; y < 8; y++)
                {
                    if(board[x,y] == b)
                    {
                        return x;
                    }
                }
            }
            return 0;
        }

        private int GetYIndex(Button b)
        {
            for (int x = 0; x < 8; x++)
            {
                for (int y = 0; y < 8; y++)
                {
                    if (board[x, y] == b)
                    {
                        return y;
                    }
                }
            }
            return 0;
        }

        private Button ButtonSelected()
        {
            if (!((prevMState.LeftButton == ButtonState.Pressed) && (mState.LeftButton == ButtonState.Released)
                && (mState.X > 50 && mState.X < 850 && mState.Y > 100 && mState.Y < 900)))
            {
                return null;
            }
            else
            {
                foreach(Button button in board)
                {
                    if(button.Recty.Left < mState.X &&
                        button.Recty.Right > mState.X &&
                        button.Recty.Top < mState.Y &&
                        button.Recty.Bottom > mState.Y)
                    {
                        return button;
                    }
                }
                return null;
            }
        }

        private Button GreyedOut()
        {
            if (!((prevMState.RightButton == ButtonState.Pressed) && (mState.RightButton == ButtonState.Released)
                && (mState.X > 50 && mState.X < 850 && mState.Y > 100 && mState.Y < 900)))
            {
                return null;
            }
            else
            {
                foreach (Button button in board)
                {
                    if (button.Recty.Left < mState.X &&
                        button.Recty.Right > mState.X &&
                        button.Recty.Top < mState.Y &&
                        button.Recty.Bottom > mState.Y)
                    {
                        return button;
                    }
                }
                return null;
            }
        }
        private Button Hover()
        {
            if (!((prevMState.LeftButton == ButtonState.Released) && (mState.LeftButton == ButtonState.Released)
                && (mState.X > 50 && mState.X < 850 && mState.Y > 100 && mState.Y < 900)))
            {
                return null;
            }
            else
            {
                foreach (Button button in board)
                {
                    if (button.Recty.Left < mState.X &&
                        button.Recty.Right > mState.X &&
                        button.Recty.Top < mState.Y &&
                        button.Recty.Bottom > mState.Y)
                    {
                        return button;
                    }
                }
                return null;
            }
        }
    }
}
